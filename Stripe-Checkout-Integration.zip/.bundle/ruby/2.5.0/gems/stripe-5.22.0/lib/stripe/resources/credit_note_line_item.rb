# frozen_string_literal: true

module Stripe
  class CreditNoteLineItem < StripeObject
    OBJECT_NAME = "credit_note_line_item"
  end
end
