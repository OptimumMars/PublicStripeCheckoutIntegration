# frozen_string_literal: true

module Stripe
  class Discount < StripeObject
    OBJECT_NAME = "discount"
  end
end
