# frozen_string_literal: true

module Stripe
  class InvoiceLineItem < StripeObject
    OBJECT_NAME = "line_item"
  end
end
