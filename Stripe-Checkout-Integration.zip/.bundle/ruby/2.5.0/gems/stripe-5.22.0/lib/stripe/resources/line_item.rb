# frozen_string_literal: true

module Stripe
  class LineItem < APIResource
    OBJECT_NAME = "item"
  end
end
