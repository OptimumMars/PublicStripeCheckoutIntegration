# frozen_string_literal: true

module Stripe
  class Mandate < APIResource
    OBJECT_NAME = "mandate"
  end
end
