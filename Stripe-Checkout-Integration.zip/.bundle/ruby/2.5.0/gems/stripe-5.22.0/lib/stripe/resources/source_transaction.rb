# frozen_string_literal: true

module Stripe
  class SourceTransaction < StripeObject
    OBJECT_NAME = "source_transaction"
  end
end
