# frozen_string_literal: true

module Stripe
  class UsageRecord < APIResource
    OBJECT_NAME = "usage_record"
  end
end
