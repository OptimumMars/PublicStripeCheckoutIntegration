# frozen_string_literal: true

module Stripe
  VERSION = "5.22.0"
end
