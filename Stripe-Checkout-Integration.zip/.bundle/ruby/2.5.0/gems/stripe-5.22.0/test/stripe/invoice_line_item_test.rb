# frozen_string_literal: true

require ::File.expand_path("../test_helper", __dir__)

module Stripe
  class InvoiceLineItemTest < Test::Unit::TestCase
  end
end
