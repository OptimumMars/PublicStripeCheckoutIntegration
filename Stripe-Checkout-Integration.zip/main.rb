#gem 'stripe'

require 'stripe'
Stripe.api_key = 'sk_test_zSypngPWGhyZlL9huyRL69bN'

session = Stripe::Checkout::Session.create({
payment_method_types: ['card'],
line_items: [{ 
  price: 'price_1GzqIhJjUQbeo3wJCgDGdXp3',
  quantity: 1,

}],
mode: 'payment',
success_url: 'https://www.google.com/search?q=success!&rlz=1C1CHBF_enUS818US818&sxsrf=ALeKk03sh9hjEy7mj1Cc0--180gt_lblLw:1593550211907&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjWvb-StarqAhUImuAKHRsgCBoQ_AUoAXoECBYQAw&biw=1223&bih=640',
cancel_url: 'https://www.google.com/search?q=cancel&tbm=isch&ved=2ahUKEwjsptiTtarqAhUHMlMKHXLGCqUQ2-cCegQIABAA&oq=cancel&gs_lcp=CgNpbWcQAzIFCAAQsQMyBQgAEIMBMgUIABCxAzIFCAAQsQMyBQgAELEDMgUIABCxAzICCAAyAggAMgIIADICCAA6BAgjECc6BwgAELEDEEM6BAgAEEM6BwgjEOoCECdQu-MDWM_yA2Co9QNoAXAAeAOAAZIBiAHLC5IBBDMuMTCYAQCgAQGqAQtnd3Mtd2l6LWltZ7ABCg&sclient=img&ei=hqX7XuzLGIfkzALyjKuoCg&bih=640&biw=1223&rlz=1C1CHBF_enUS818US818',


})